# Vinegar CLI 1.0
- A basic command line CLI to convert files to pickles of pandas DataFrames
so that you make universal pipelines to pickles no matter the format your data
arrives in.

# Installation

```bash
pip install vinegar
```

# Usage

To convert a csv to a pandas df as a pickle.

```bash
vinegar example.csv
```
