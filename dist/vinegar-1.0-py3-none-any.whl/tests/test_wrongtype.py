def test_wrongtype():
    assert(1==1)
#    assert(vinegar('file.jpg')) == 'Invalid filetype'
